The results are summarized in report.pdf
The src directory contains written code (single R script). The sections are separated by comments.
The R script included makes use of a working directory that will have to be changed for the script to run. 
Additionally the included packages at the top of the script must be installed before the script will run.
These packages are: 
-klaR
-caret
-stringr
-randomForest
-svmlight
-RANN
-cluster
-stats
