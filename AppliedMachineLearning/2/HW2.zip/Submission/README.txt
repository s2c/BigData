The results are summarized in report.pdf
The src directory contains written code (single R script)
The R script included makes use of a working directory that will have to be changed for the script to run. 
Additionally the included packages at the top of the script must be installed before the script will run. None of them are used for classification.