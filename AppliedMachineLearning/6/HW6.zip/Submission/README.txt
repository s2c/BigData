src folder contains all source code.
data folder contains all data.
