src folder contains all source code.
fig folder contains all images.
explanation_of_variance.pdf contains segmented images for polarlights.jpg using different starting points and our report of the variation we see and our explanation of why.

To run source code, open and run in MATLAB.

Each part of the assignment has two versions of the code - in the original version (HW5_topic_model.m and HW5_image_segmentation.m), the pi’s and p’s or mu’s are initialized to values that are close to even, plus a small amount of gaussian random noise.  In  the "randomStarts" version (HW5_topic_model_randomStarts.m and HW5_image_segmentation_randomStarts.m), the pi’s and p’s or mu’s are initialized in a uniform random fashion.  Figures in the fig folder for the original version are labeled as "evenInitialValues" and for the uniform random version are labeled as "randomizedInitialValues".  "Forced iterations" indicates that the models were forced to continue running for a set number of iterations, generally beyond convergence, whereas "until convergence" suggests that the models were only run until our convergence criteria were met.

The segmentation of images entailed running the algorithm for a fixed 15 iterations due to time considerations.


