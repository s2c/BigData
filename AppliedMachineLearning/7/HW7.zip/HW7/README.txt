src folder contains all source code.
data folder contains all data.
results folder contains results of the analyses.
cs498dafHW7Writeup.pdf is our written report.
